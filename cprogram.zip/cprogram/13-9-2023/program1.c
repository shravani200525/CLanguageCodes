#include<stdio.h>
void main()
{
	int a=10;
	int ans;

	printf("%d\n",a);
	ans= ++a;
	printf("%d\n",ans);
	ans = a++;
	printf("%d\n",ans);
	printf("%d\n",a);
}
