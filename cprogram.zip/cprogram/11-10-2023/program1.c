#include<stdio.h>
void main()
{
	int a=10;
	int a=10;
}
