#include<stdio.h>

void main()
{
	char wing = 'A';
	printf("enter wing\n");
	scanf("%c",&wing);
	printf("wing is = %c\n",wing);
}
