#include<stdio.h>

void main()
{
	float marks;
	printf("enter marks\n");
	scanf("%f",&marks);
	printf("marks is= %f\n",marks);
}
