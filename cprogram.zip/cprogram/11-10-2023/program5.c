#include<stdio.h>

void main()
{
	double price;
	printf("enter price\n");
	scanf("%lf",&price);
	printf("price is= %lf\n",price);
}
