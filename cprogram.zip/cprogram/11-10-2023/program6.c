#include<stdio.h>

void main()
{
	char ch;
	printf("enter character\n");
	scanf("%c",&ch);
	if(ch>='A' && ch<='Z')
	{
		printf("enter character is upper\n");
	}
	if(ch>='a' && ch<='z')
	{
		printf("enter character is lower\n");
	}
}
