#include<stdio.h>
void main()
{
	int age;
	printf("enter age\n");
	scanf("%d",&age);
	printf("age = %d\n",age);
}
