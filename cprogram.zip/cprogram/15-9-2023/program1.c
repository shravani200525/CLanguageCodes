#include<stdio.h>

int main()
{
	int a =5;
	int ans;

	ans = ++a + ++a;
	printf("ans = %d\n",ans);
	printf("a = %d\n",a);
	return (0);
}
