#include<stdio.h>

void main()
{
	int a = 0; int b=1;
	int ans;
	 ans = a++ && b++;
	 printf("ans=%d\n",ans);
	 printf("a=%d\n",a);
	 printf("b=%d\n",b);
}
