#include<stdio.h>

void main()
{
	int a =0; int b= 1;
	int ans;
	printf("%d\n",a||b);
	printf("%d\n",b||a);
	printf("%d\n",a||a);
	printf("%d\n",b||b);
}
