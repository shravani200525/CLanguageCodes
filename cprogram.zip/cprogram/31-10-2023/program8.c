#include<stdio.h>

void main()
{
	char ch='A';
	for(int i=1;i<=3;i=i+1)
	{
		for(int j=1;j<=3;j=j+1)
		{
			printf(" %c",ch);
			ch=ch+2;
		}
	printf("\n");
	}
}
