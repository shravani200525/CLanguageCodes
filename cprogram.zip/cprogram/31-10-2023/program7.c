#include<stdio.h>
void main()
{
	char ch='F';
	for(int i=3;i>=1;i--)
	{
		for(int j=3;j>=i;j--)
		{
			printf(" %c",ch);
			ch--;
		}
	printf("\n");
	}
}
