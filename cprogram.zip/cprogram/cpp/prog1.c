#include<stdio.h>
void main()
{
	int fact=1,i,no;
	printf("enter no:");
	scanf("%d",&no);
	for(i=1;i<=no;i++)
	{
		fact = fact *i;
	}
	printf("factorial of:%d\n",fact);
}
