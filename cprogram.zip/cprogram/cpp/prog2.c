#include<stdio.h>
void main()
{
	int no;
	printf("enter no:");
	scanf("%d",&no);
	if(no % 2==0)
	{
		printf("no is odd\n");
	}
	else
	{
		printf("no is even\n");
	}
}
