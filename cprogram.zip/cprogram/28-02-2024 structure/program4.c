
#include<stdio.h>
struct member
{
    char name[20];
    float charge;
    int flatno;
}obj1={"shravani",500.1,21};

void main()
{
    struct member obj2;
    obj2.name={'p','r','a','t','i','k'};
    obj2.charge=900.0;
    obj2.flatno=78;
}