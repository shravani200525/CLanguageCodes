
#include<stdio.h>
#include<string.h>
struct member{
    char name[20];
    float charge;
    int flatno;
}obj1={"chika",60.12,101};

void main()
{
    
    printf("enter name\n");
    gets(obj1.name);
    printf("enter charge\n");
    scanf("%f",obj1.charge);
    printf("enter flat no\n");
    scanf("%d",obj1.flatno);

    printf("%s\n",obj1.name);
    printf("%f\n",obj1.charge);
    printf("%d\n",obj1.flatno);

  
    
}