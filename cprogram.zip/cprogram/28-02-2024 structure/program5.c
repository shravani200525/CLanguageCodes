#include<stdio.h>
#include<string.h>
struct member{
    char name[20];
    float charge;
    int flatno;
}obj1={"chika",60.12,101};

void main()
{
    struct member obj2;
    strcpy(obj2.name,"kinu");
    obj2.charge=70.15;
    obj2.flatno=102;

    printf("%s\n",obj1.name);
    printf("%f\n",obj1.charge);
    printf("%d\n",obj1.flatno);

    printf("%s\n",obj2.name);
    printf("%f\n",obj2.charge);
    printf("%d\n",obj2.flatno);

    
}