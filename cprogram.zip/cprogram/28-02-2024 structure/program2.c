#include<stdio.h>

struct member{
	char wing='a';
	float charge=5.25;
	int fno=101;
};
