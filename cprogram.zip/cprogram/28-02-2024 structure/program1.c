#include<stdio.h>

struct cricketplayer{
	int jerno;
	float avg;
	char grade;


};
	void main()
{
	//struct cricketplayer();
	/
	printf("%ld\n",sizeof(struct cricketplayer));
}
