#include<stdio.h>

struct member{
	char name[20];
	float charge;
	int fno;
}obj1={"shravani", 50.23 ,12};

void main(){
	struct member obj2={"jidnya", 96.52, 13};

	printf("%s\n",obj1.name);
	printf("%f\n",obj1.charge);
	printf("%d\n",obj1.fno);

	printf("%s\n",obj2.name);
	printf("%f\n",obj2.charge);
	printf("%d\n",obj2.fno);
}
