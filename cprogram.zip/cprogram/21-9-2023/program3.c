#include<stdio.h>

int logical_AND(int a,int b);
void main()
{
	int AND1 logical_AND(0,1);
	printf("a&&b : %d\n",AND1);

	int AND2 logical_AND(1,0);
	printf("b&&a : %d\n",AND2);

	int AND3 logical_AND(0,0);
	printf("a&&a : %d\n",AND3);

	int AND4 logical_AND(1,1);
	printf("b&&b : %d\n",AND4);
}

int logical_AND(int a, int b);
{
	int a&&b;
	return a&&b;
}
