#include<stdio.h>

int logical_OR(int a, int b);
void main()
{
	int or = logical_OR(0,1);
	printf("a||b: %d\n",or);

	int or1 = logical_OR(1,0);
	printf("b||a: %d\n",or1);

	int or2 = logical_OR(0,0);
	printf("a||a: %d\n",or2);

	int or3 = logical_OR(1,1);
	printf("b||b: %d\n",or3);
}
int logical_OR(int a,int b)
{
	int (a||b);
	return (a||b);
}
