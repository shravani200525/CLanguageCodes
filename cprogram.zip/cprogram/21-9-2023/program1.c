#include<stdio.h>

int addition (int a,int b);

void main()
{
	int add = addition(20,30);
	printf("addition = %d\n",add);

	int add1= addition(50,50);
	printf("add1= %d\n",add1);

}

int addition (int a, int b)
{
	int add = a+b;
	return add;
}
