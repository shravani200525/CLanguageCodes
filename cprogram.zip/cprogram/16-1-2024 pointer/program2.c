#include<stdio.h>
void main()
{
	int num1=10;
	int num2=20;
	int *ptr1=&num1;
	int *ptr2=&num2;

	printf("%p\n",ptr1);
	printf("%p\n",ptr2);

	printf("%d\n",*ptr1);
	printf("%d\n",*ptr2);

	printf("%d\n",*ptr1 + *ptr2);
	printf("%p\n",*ptr1 + *ptr2);
	
}
