#include<stdio.h>
void main()
{
	int num1=10;
	int num2=20;

	int *ptr=&num1;

	printf("%p\n",ptr);
	printf("%d\n",*ptr);

	printf("%p\n",ptr+1);
	printf("%d\n",*(ptr+1));
}
