#include<stdio.h>

void main()
{
	char ch1='A';
	char ch2='B';

	char *ptr = &ch1;

	printf("%p\n",ptr);
	printf(" %c\n",*ptr);

	printf(" %d\n",*(ptr+1));
}
