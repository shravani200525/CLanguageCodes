#include<stdio.h>

void main()
{
	int num=100;
	char ch1='B';

	int *ptr1=&num;
	char *ptr2=&ch1;

	printf("%p\n",ptr1);
	printf("%p\n",ptr2);

	printf("%d\n",*ptr1);
	printf("%c\n",*ptr2);

}
