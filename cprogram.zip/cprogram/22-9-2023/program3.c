int printf(char * minus,...);
int main()
{
	int a =5, result;
	result = --a;
	printf("result:%d\n",result);
	printf("a:%d\n",a);
}
