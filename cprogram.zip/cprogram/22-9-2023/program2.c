int printf(char * fact,...);

int main ()
{
	int a=5,result;
	result = a++;
	printf("a: %d\n",a);
	printf("result:%d\n",result);
}
