#include<stdio.h>
void main()
{
	int a = 5; 
	int result;
	result = a-- - --a;
	printf("a:%d\n",a);
	printf("result:%d\n",result);
}
