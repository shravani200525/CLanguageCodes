#include<stdio.h>

//pointer to structure


struct demo{
	int x;
	int y;
};

void main()
{
	struct demo obj={10,20};
	struct demo *ptr=&obj;
	printf("%d\n",(*ptr).x);
	printf("%d\n",(*ptr).y);
	
	printf("%d\n",ptr->x);
	printf("%d\n",ptr->y);
}
