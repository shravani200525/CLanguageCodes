#include<stdio.h>

//integer of function


void fun1(int a,int b);
void fun2(int *a,int *b);

void main()
{
	int a=10;
	int b=20;
	fun1(a,b);
	fun2(&a,&b);
}

void fun1(int a,int b){
	printf("%d\n",a);
	printf("%d\n",b);
}

void fun2(int *a,int *b){
	printf("%p\n",&a);
	printf("%p\n",&b);
}
