#include<stdio.h>

//pointer to integer


void main()
{
	int a=10;
	int *ptr=&a;
	printf("%p\n",ptr);
	printf("%d\n",*ptr);
}
