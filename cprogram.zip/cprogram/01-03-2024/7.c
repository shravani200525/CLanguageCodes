// structure declaration

#include<stdio.h>

struct ipl{
	char name[20];
	int noteam;
	float price;
};

void main()
{
	printf("%ld\n",sizeof(struct ipl));
}
