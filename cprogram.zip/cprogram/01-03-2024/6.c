#include<stdio.h>

//structure to function


struct demo{
	int x;
	int y;
};
void fun1(int x,int y);
void fun2(int x,int y);
void main()
{
	struct demo obj={10,20};
	fun1(obj);
	fun2(obj);
}

void fun1(struct demo obj){
	printf("%d\n",obj.x);
	printf("%d\n",obj.y);
}

void fun2(struct demo *ptr){
	printf("%d\n",ptr->x);
	printf("%d\n",(*ptr).y);
}
