#include<stdio.h>

//array of structure


struct demo{
	int x;
	int y;

};

void main()
{
	struct demo obj1={10,20};
	struct demo obj2={30,40};

	struct demo arr[2]={obj1,obj2};

	//printf("%d\n",arr[0].x);
	//printf("%d\n",arr[0].y);

	//printf("%d\n",arr[1].x);
	//printf("%d\n",arr[1].y);
	

	//OR
	
	for(int i=0;i<2;i++)
	{
		printf("%d\n",arr[i].x);
		printf("%d\n",arr[i].y);
	}
}
