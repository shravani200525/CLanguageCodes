#include<stdio.h>

//array of integer


void main()
{
	int a=10;
	int b=20;
	int c=30;
	int arr[3]={a,b,c};
	printf("%d\n",arr[0]);
	printf("%d\n",arr[1]);
	printf("%d\n",arr[2]);
	arr[0]=90;
	printf("%d\n",arr[0]);

	*(arr+0)=50;
}
