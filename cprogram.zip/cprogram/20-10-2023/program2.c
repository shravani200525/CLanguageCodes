#include<stdio.h>

void main()
{
	float x= 85.56;
	switch(x)
	{
		case 85.56:
			printf("value of 65\n");
			break;
		case 66.56:
			printf("value of 66\n");
			break;
		case 67.89:
			printf("value of 67\n");
			break;
		case 67.45:
			printf("value of 67+A\n");
			break;
		case 68.25:
			printf("value of 68\n");
			break;
		default:
			printf("wrong\n");
			break;
	}
}
