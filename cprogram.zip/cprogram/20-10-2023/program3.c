#include<stdio.h>
void main()
{
	char x='A';
	printf("enter value for x\n");
	scanf("%c",&x);
	switch(x)
	{
		case 'A':
			printf("A\n");
			break;
		case 'B':
			printf("B\n");
			break;
		case 'C':
			printf("C\n");
			break;
		default:
			printf("wrong\n");
			break;
	}
}
