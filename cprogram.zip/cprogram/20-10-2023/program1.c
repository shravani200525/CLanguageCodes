#include<stdio.h>
void main()
{
	int x;
	printf("enter value of x\n");
	scanf("%d",&x);
	switch(x)
	{
		case 65:
			printf("value of 65\n");
			break;
		case 66:
			printf("value of 66\n");
			break;
		case 67:
			printf("value of 67\n");
			break;
		case 67+'A':
			printf("value of 67+A\n");
			break;
		case 68:
			printf("value of 68\n");
			break;
		default:
			printf("wrong\n");
			break;
	}
}
