#include<stdio.h>
void main()
{
	int x;
	printf("enter value\n");
	scanf("%d",&x);
	switch(x)
	{
		case 97:
			printf("value of 97\n");
			break;
		case 98:
			printf("value of 98\n");
			break;
		case 99:
			printf("value of 99\n");
			break;
		case 100:
			printf("value of 100\n");
			break;
		default:
			printf("wrong input\n");
			break;
	}
}
