#include<stdio.h>

void main()
{
	int x;
	printf("enter value\n");
	scanf("%d",&x);
	switch(x)
	{
		case 97:
			printf("value of x\n");
			break;
		case 'a':
			printf("value of a\n");
			break;
		case 98:
			printf("value of 98\n");
			break;
		case 'b':
			printf("value of b\n");
			break;
		default:
			printf("wrong input\n");
			break;
	}
}
