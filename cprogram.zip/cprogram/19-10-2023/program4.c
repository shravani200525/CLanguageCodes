#include<stdio.h>


void main()
{
	const int x=10;
	printf("%d\n",x);
	x=20;
	printf("%d\n",x);
}
