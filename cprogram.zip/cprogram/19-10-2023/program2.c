#include<stdio.h>

void main()
{
	int x;
	printf("enter value\n");
	scanf("%d",&x);
	switch(x)
	{
		case 1:
			printf("value of 1\n");
			break;
		case 1:
			printf("value of 1\n");
			break;
		case 2:
			printf("value of 2\n");
			break;
		case 2:
			printf("value of 2\n");
			break;
		default:
			printf("wrong input\n");
			break;
	}
}
