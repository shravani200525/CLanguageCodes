#include<stdio.h>
void getinfo()


void main()
{
	int b = 20;
	printf("main\n");
	getinfo();
	printf("end\n");
}
void getinfo()
{
	int x = 5;
	int y =6;
	int ans;
	ans = ++y + ++y;
	printf("ans:%d\n",ans);
	printf("a:%d\n",x);
	printf("b:%d\n",y);
}
