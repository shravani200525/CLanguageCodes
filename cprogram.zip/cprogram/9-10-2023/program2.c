#include<stdio.h>
void main()
{
	int a =15,b=25,ans;
	ans = a&b;
	printf("ans:%d\n",ans);
	printf("a:%d\n",a);
	printf("b:%d\n",b);
}
