#include<stdio.h>
void main()
{
	int a=58,b=98,ans1,ans2;
	ans1 = a++<<2;
	ans2 = ++b<<2;
	printf("ans1:%d\n",ans1);
	printf("ans2:%d\n",ans2);
	printf("a:%d\n",a);
	printf("b:%d\n",b);
}
