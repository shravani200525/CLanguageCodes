#include<stdio.h>

int num1=10;
int num2=20;
int ans;
int main()
{
	printf("start main\n");
	puts("[1] Addition");
	ans = num1 + num2;
	printf("%d\n",ans);
	printf("end\n");
	return(0);
}
