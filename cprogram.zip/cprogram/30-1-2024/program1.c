#include<stdio.h>
void main()
{
	//wild pointer
	int *iptr;
	printf("%p\n",iptr);
	printf("%d\n",*iptr);
}
