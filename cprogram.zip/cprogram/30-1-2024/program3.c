#include<stdio.h>
void main()
{
	int num=10;
	int *ptr2=NULL;
	ptr2=&num;
	printf("%d\n",*ptr2);
}
