#include<stdio.h>
void main()
{
	//null pointer
	int *ptr1=0;
	printf("%p\n",ptr1);
	//printf("%d\n",*ptr1);
}
