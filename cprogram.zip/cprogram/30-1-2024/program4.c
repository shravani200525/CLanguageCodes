#include<stdio.h>
void main()
{
	int num=10;
	int *ptr=&num;
	printf("%d\n",*ptr);
	//*ptr=50;
	
	*ptr=*ptr;
	printf("%d\n",*ptr);

}
