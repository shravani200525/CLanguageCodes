#include<stdio.h>
void main()
{
	int a=10;

	int *ptr1=&a;
	int *ptr2=a;

	printf("%d\n",a);
	printf("%p\n",ptr1);
	printf("%p\n",ptr2);

	printf("%d\n",*ptr1);
	printf("%d\n",*ptr2);//segmentation fault
}
