#include<stdio.h>

void main()
{
	int a=10,b=11;
	
	int *ptr1 =&a;
	int *ptr2 = a;
	int *ptr3=&b;
	int *ptr4=b;

	printf("%p\n",ptr1);
	printf("%p\n",ptr2);
	printf("%p\n",ptr3);
	printf("%p\n",ptr4);

	printf("%d\n",a);
	printf("%d\n",b);
	printf("%p\n",&a);
	printf("%p\n",&b);
}
