#include<stdio.h>
void main()
{
	int studentAge1;
	int studentAge2;
	int studentAge3;
	int studentAge4;
	int studentAge5;

	printf("enter student 1 Age\n");
	scanf("%d",&studentAge1);
	scanf("%d",&studentAge2);
	scanf("%d",&studentAge3);
	scanf("%d",&studentAge4);
	scanf("%d",&studentAge5);

	printf("student 1 Age:%d\n",studentAge1);
	printf("student 2 Age:%d\n",studentAge2);
	printf("student 3 Age:%d\n",studentAge3);
	printf("student 4 Age:%d\n",studentAge4);
	printf("student 5 Age:%d\n",studentAge5);
}
