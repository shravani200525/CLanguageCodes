#include<stdio.h>
void main()
{
	int hunger = 1;
	if(hunger>=1)
	{
		printf("need a food\n");
	}
}
