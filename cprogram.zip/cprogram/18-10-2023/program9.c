#include<stdio.h>
void main()
{
	int fan=1;
	if(fan>=0)
	{
		printf("fan is on\n");
	}
}

