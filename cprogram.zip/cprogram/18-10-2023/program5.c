#include<stdio.h>
void main()

{
	int tv=1;
	if(tv>=0)
	{
		printf("tv is on\n");
	}
	else
	{
		printf("tv is off\n");
	}
}
