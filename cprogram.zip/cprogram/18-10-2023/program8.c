#include<stdio.h>
void main()
{
	int library_card=1;
	if(library_card<=1)
	{
		printf("card is always need for books issue\n");
	}

}
