#include<stdio.h>
void main()
{
	int school_id = 1;
	if(school_id>=0)
	{
		printf("id is always recomended for school\n");
	}
}
