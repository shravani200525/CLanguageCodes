#include<stdio.h>
void main()
{
	char doctor='y';
	if(doctor>=0)
	{
		printf("doctor is available\n");
	}
	else
	{
		printf("doctor is not availbale\n");
	}
}
