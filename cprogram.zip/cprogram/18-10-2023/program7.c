#include<stdio.h>
void main()
{
	int age=20;
	if(age>=18)
	{
		printf("eligible for voting\n");
	}
}
