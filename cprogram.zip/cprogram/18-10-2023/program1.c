#include<stdio.h>
void main()
{
	char signal ='y';
	if(signal>=1)
	{
		printf("signal is red\n");
	}
	else
	{
		printf("signal is green\n");
	}
}
