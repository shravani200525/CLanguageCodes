#include<stdio.h>
void main()
{
	int library = 1;
	if(library <=1)
	{
		printf("books available\n");
	}
	else
	{
		printf("books not available\n");
	}
}
