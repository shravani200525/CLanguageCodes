#include<stdio.h>
void main()
{
	char sub_sanskrit = 'y';
	if(sub_sanskrit<=1)
	{
		printf("sub is present\n");
	}
	else
	{
		printf("sub is not available\n");
	}
}
