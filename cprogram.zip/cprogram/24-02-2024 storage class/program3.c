#include<stdio.h>

//static example


void fundemo(int n1)
{

	printf("%d\n",n1);
	n1++;
	printf("%d\n",n1);

}
void main()
{

	fundemo(10);
	fundemo(10);
	fundemo(10);
	fundemo(10);

}
