#include<stdio.h>


//auto example

auto int n2=20;
void main()
{
	auto int n1=10;
	printf("%d\n",n1);
}
