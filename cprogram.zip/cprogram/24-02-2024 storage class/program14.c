#include<stdio.h>

static void fun(int a,int b)
{
	printf("%d\n",a);
	printf("%d\n",b);
}
