#include<stdio.h>

void fun()
{

	extern int n1;
	n1 = n1 + 1;
	printf("%d\n",n1);

}
