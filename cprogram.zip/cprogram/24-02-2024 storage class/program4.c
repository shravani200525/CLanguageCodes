#include<stdio.h>

//static example

int n1=10;

void fundemo()
{
	//static int n1=10;
	n1++;
	printf("%d\n",n1);
}

void main()
{

	fundemo();
	fundemo();
	fundemo();
	fundemo();
}
