#include<stdio.h>

void main()
{
	extern int n1=40;
	printf("%d\n",n1);
	printf("%p\n",&n1);

}

//static int n1=10;
