#include<stdio.h>

void fun();
//int n1=10;
void main()
{
	fun();
}
