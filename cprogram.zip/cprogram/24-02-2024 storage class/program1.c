#include<stdio.h>


//register example
register int n2=20;
void main()
{
	register int n1=10;

	printf("%d\n",n1);
}
