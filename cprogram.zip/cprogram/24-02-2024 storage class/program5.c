#include<stdio.h>

static int n1=10;   //static global

void fundemo()
{
	//static int n1=10; //static local

	n1++;
	printf("%d\n",n1);
}

void main()
{

	fundemo();
	printf("%d\n",n1);
	fundemo();
	printf("%d\n",n1);
	fundemo();
	printf("%d\n",n1);
	fundemo();
	printf("%d\n",n1);

}
