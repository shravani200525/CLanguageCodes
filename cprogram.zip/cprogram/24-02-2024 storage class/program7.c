#include<stdio.h>

void fun()
{
	extern int n1;
	printf("%d\n",n1);
	
}

int n1=50;
