#include<stdio.h>

extern void fun( int a, int b)
{
	printf("%d\n",a);
	printf("%d\n",b);
}

void main()
{
	fun(10,20);
}
