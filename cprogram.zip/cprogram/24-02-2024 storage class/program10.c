#include<stdio.h>

int n1=10;
