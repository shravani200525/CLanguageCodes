#include<stdio.h>

void fun(int a, int b);

void main()
{
	fun(10,20);
}
