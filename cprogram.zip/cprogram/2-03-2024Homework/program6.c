//nested structure

#include<stdio.h>
#include<string.h>

//2nd way

//struct IPL{
	//char tName[20];
	//int noTeams;
	//float price;
	//struct Matchdate{
	//	int day;
	//	int month;
	//	int year;
//	}obj1;
//}

//1st way

struct Matchdate{
	int day;

	int month;
	int year;
};

struct IPL{
	char tName[20];
	int noTeams;
	float price;
	struct Matchdate obj1;
};

void main()
{
	struct IPL obj2={"pune",20,200.31,{1,3,2024}};

	printf("%s\n",obj2.tName);
	printf("%d\n",obj2.noTeams);
	printf("%f\n",obj2.price);

	//printf("%d-%d-%d\n",obj2.obj1.day,obj2.obj1.month,obj2.obj1.year);
	printf("%d\n",obj2.obj1.day);
	printf("%d\n",obj2.obj1.month);
	printf("%d\n",obj2.obj1.year);
}
