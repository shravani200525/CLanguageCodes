//passing structure to function

#include<stdio.h>

void funOne();
void funTwo();
struct demo{
	int n1;
	int n2;
};

void main()
{
	struct demo obj1={10,20};

	funOne(obj1);
	funTwo(&obj1);
}

void funOne(struct demo obj1){
	printf("from funOne\n");

	printf("%d\n",obj1.n1);
	printf("%d\n",obj1.n2);
}

void funTwo(struct demo *ptr){
	printf("from funTwo\n");

	printf("%d\n",ptr->n1);
	printf("%d\n",ptr->n2);
}

