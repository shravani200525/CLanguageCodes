//structure initialization through malloc function


#include<stdio.h>
#include<stdlib.h>

char* mystrcpy(char* dest,char* src);
struct IPL{
	char tName[20];
	int noTeams;
	float price;
};

void main()
{
	struct IPL *ptr=(struct IPL*)malloc(sizeof(struct IPL));//malloc structure initialization

	mystrcpy((*ptr).tName,"pune");
	ptr->noTeams=20;
	ptr->price=56.21;

	printf("%s\n",ptr->tName);
	printf("%d\n",ptr->noTeams);
	printf("%f\n",ptr->price);
}

char* mystrcpy(char* dest,char* src){
	while(*src != '\0'){
		*dest=*src;
		dest++;
		src++;
	}
	*dest ='\0';
}

