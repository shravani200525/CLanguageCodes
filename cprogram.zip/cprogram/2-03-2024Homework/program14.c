//typedef -> alias name

#include<stdio.h>
//#include"demo1.h"

typedef int ajay;
void main()
{
	int a=10;
	printf("%d\n",a);

	ajay b=20;
	printf("%d\n",b);
}
