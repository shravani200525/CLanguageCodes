//union -> one at a time

#include<stdio.h>
#include<string.h>

union Demo{
	char arr[10];
	int x;
	int y;
	double c;
};

void main()
{
	printf("%ld\n",sizeof(union Demo));
	union Demo obj1;

	strcpy(obj1.arr,"shravani");
	printf("%s\n",obj1.arr);

	obj1.x=10;
	printf("%d\n",obj1.x);

	obj1.y=20;
	printf("%d\n",obj1.y);
	
	obj1.c=23;
	printf("%lf\n",obj1.c);
}
