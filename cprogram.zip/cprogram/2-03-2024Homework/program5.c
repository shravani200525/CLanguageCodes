//array of structure object

#include<stdio.h>
#include<string.h>

struct IPL{
	char tName[20];
	int noTeams;
	float price;
};

void main()
{
	struct IPL obj2023={"pune",10,56.78};
	struct IPL obj2024={"mumbai",20,384.34};

	struct IPL arr[2]={obj2023,obj2024};

	for(int i=0;i<2;i++){
		printf("%s\n",arr[i].tName);
		printf("%d\n",arr[i].noTeams);
		printf("%f\n",arr[i].price);
	}
}
