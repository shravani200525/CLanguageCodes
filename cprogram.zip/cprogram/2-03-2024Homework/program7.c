//unnamed structure

#include<stdio.h>

struct {
	int x;
	int y;
}obj1={10,20};

void main()
{
	printf("%d\n",obj1.x);
	printf("%d\n",obj1.y);
}
