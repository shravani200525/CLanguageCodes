//pointer to structure

#include<stdio.h>
#include<string.h>

struct IPL{
	char tName[20];
	int noTeams;
	float price;
}obj2023={"mumbai",10,90.87};

void main()
{
	struct IPL *ptr=&obj2023;

	printf("%s\n",ptr->tName);
	printf("%d\n",ptr->noTeams);
	printf("%f\n",ptr->price);
}
