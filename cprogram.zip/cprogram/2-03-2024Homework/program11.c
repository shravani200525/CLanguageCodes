//union initialization -> warning
//one at a time

#include<stdio.h>

union demo{
	char arr[10];
	int x;
	int y;
	double c;
};

void main()
{
	printf("%ld\n",sizeof(union demo));
	union demo obj1={"shravani",10,20,2};

	printf("%s\n",obj1.arr);
	printf("%d\n",obj1.x);
	printf("%d\n",obj1.y);
	printf("%lf\n",obj1.c);
}
