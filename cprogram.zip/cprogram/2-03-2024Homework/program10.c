//structure elements addresses different

#include<stdio.h>

struct Demo{
	char arr[10];
	int x;
	int y;
	double c;
};

void main()
{
	printf("%ld\n",sizeof(struct Demo));
	struct Demo obj1;

	printf("%p\n",&obj1.arr);
	printf("%p\n",&obj1.x);
	printf("%p\n",&obj1.y);
	printf("%p\n",&obj1.c);
}
