//pointer to integer

//pointer to array


#include<stdio.h>

void main()
{
	int a=10;
	int *ptr=&a;

	printf("%d\n",a);
	printf("%d\n",*ptr);

	int arr[5]={10,20,30,40,50};

	int *ptr2=arr;

	for(int i=0;i<5;i++){
		printf("%d\n",*(ptr2+i));
	}

}
