//structure declaration

//structure initialization through objects


#include<stdio.h>
#include<string.h>

void fun();
struct IPL{
	char tName[20];
	int noTeams;
	float iPrice;
}obj2023={"Mumbai Indians",10,1000.00};//global

void main(){
	struct IPL obj2024={"Pune Worriors",12,200.23};//local

	printf("%ld\n",sizeof(struct IPL));

	printf("obj2023\n");
	printf("%s\n",obj2023.tName);
	printf("%d\n",obj2023.noTeams);
	printf("%f\n",obj2023.iPrice);

	printf("obj2024\n");
	
	printf("%s\n",obj2024.tName);
	printf("%d\n",obj2024.noTeams);
	printf("%f\n",obj2024.iPrice);

	struct IPL obj2025;//local

	strcpy(obj2025.tName,"kolkata");
	obj2025.noTeams=14;
	obj2025.iPrice=500.25;

	printf("obj2025\n");

	printf("%s\n",obj2025.tName);
	printf("%d\n",obj2025.noTeams);
	printf("%f\n",obj2025.iPrice);

	struct IPL obj2026;//local
	
	printf("enter team name\n");
	gets(obj2027.tName);

	printf("enter no of teams\n");
	scanf("%d",&obj2026.noTeams);

	printf("Enter Total price\n");
	scanf("%f",&obj2026.iPrice);

	printf("obj2026\n");
	printf("%s\n",obj2026.tName);
	printf("%d\n",obj2026.noTeams);
	printf("%f\n",obj2026.iPrice);

	fun();//local

}

void fun(){
	struct IPL obj2027={"mumbai",20,200.69};//local

	printf("obj2027\n");
	printf("%s\n",obj2027.tName);
	printf("%d\n",obj2027.noTeams);
	printf("%f\n",obj2027.iPrice);
}
