//union elemnts addresses same

#include<stdio.h>

union demo{
	char arr[10];
	int x;
	int y;
	double c;
};

void main()
{
	printf("%ld\n",sizeof(union demo));//12

	union demo obj1;
	printf("%p\n",&obj1.arr);
	printf("%p\n",&obj1.x);
	printf("%p\n",&obj1.y);
	printf("%p\n",&obj1.c);
}

