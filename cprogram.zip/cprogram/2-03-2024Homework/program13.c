//enum -> improves readability

#include<stdio.h>
//#include "demo.h"
enum friends{
	mon=1,
	tue,
	wed,
	thu,
	fri,
	sat,
	sun
};

void main()
{
	int day = sun;
	printf("%d\n",day);
}
