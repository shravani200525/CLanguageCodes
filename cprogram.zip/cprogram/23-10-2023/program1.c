#include<stdio.h>
void main()
{
	int input;
	printf("enter value\n");
	scanf("%d",&input);
	switch(input)
	{
		case 1:
			printf("1\n");
			break;
		case 10%5==0:
			printf("Two\n");
			break;
		case 3:
			printf("Three\n");
			break;
		case 4:
			printf("Four\n");
			break;
		default:
			printf("wrong\n");
			break;
	}
}
