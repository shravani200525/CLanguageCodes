#include<stdio.h>
void main()
{
	int input;
	printf("enter value\n");
	scanf("%d",&input);
	int x=5;
	int y=6;
	switch(input)
	{
		case 'x'+'y':
			printf("Two\n");
			break;
		default:
			printf("wrong\n");
			break;
	}
}
