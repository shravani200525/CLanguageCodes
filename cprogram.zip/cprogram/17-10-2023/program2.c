#include<stdio.h>
void main()
{
	int pmoney=2500;
	if(pmoney>=2500)
	{
		printf("club\n");
	}
	else if(pmoney>=2000)
	{
		printf("hotel\n");
	}
	else if(pmoney>=1000)
	{
		printf("cake\n");
	}
	else if(pmoney>=500)
	{
		printf("cafe\n");
	}
	else
	{
		printf("vadapav\n");
	}
}
