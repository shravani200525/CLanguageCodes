#include<stdio.h>

void main()
{
	int budget=5000;

	if(budget>5000)
	{
		printf("going to waterpark\n");
	}
	else if(budget >3000)
	{
		printf("shopping\n");
	}
	else if(budget > 2000)
	{
		printf("movie\n");
	}
	else if(budget > 1000)
	{
		printf("tulshibag\n");
	}
	else
	{
		printf("stay home\n");
	}
}
