#include<stdio.h>
int a;
void main()
{
	int a=10,b=20,ans;
	ans=a+b;
	printf("ans=%d\n",ans);
	ans = ++a + ++b;
	printf("ans=%d\n",ans);
	printf("a=%d\n",a);
	printf("b=%d\n",b);
}
