#include<stdio.h>

void main()
{
	int a=5;
	int b=6;
	int ans;

	ans = a++ + ++a + b++ + ++b;
	printf("a= %d\n",a);
	printf("b = %d\n",b);
	printf("ans = %d\n",ans);
}
