#include<stdio.h>

void main()
{
	int num = 5;
	int result;

	result = ++num;
	printf("%d\n",num);
	printf("%d\n",result);
}
