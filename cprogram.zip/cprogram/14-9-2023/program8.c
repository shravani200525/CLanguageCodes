#include<stdio.h>

void main()
{
	int a=5;
	int b=6;
	int ans1;
	int ans2;
	ans1 = ++a + a++ + --a + a--;
	printf("ans1=%d\n",ans1);
	printf("a=%d\n",a);

	ans2 = ++b + b++ + --b + b--;
	printf("ans2=%d\n",ans2);
	printf("b=%d\n",b);

}
