#include<stdio.h>
void main()
{
	int num1=10;
	int num2=20;
	int result;
	result=num1+num2;
	printf("result = %d\n",result);
	num1 =50; 
	num2=50;
	result= num1 + num2;
	printf("result=%d\n",result);
}
