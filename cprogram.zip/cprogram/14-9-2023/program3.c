#include<stdio.h>
void main()
{
	int num=5;
	int result;

	result = num++;
	printf("num = %d\n",num);
	printf("result = %d\n",result);
}
