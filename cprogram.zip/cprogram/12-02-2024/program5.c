#include<stdio.h>

void fundemo(int a,int b,int c)
{
	a=a+100;
	b=b+200;
	c=c+300;
	return (a,b,c);
}

void main()
{

	int n1=10;
	int n2=20;
	int n3=30;
	int a=  fundemo(n1,n2,n3);
	printf("%d\n",a);

}
