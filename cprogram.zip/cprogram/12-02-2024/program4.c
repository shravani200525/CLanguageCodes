#include<stdio.h>

void swap(int *n1,int *n2);
void main()
{
	int n1=10;
	int n2=20;
	printf("%d\n",n1);//10
	printf("%d\n",n2);//20
	swap(&n1,&n2);
	printf("%d\n",n1);
	printf("%d\n",n2);

}

void swap(int *n1,int *n2)
{
	int temp;
	temp=*n1;
	*n1=*n2;
	*n2=temp;
	printf("%d\n",*n1);
	printf("%d\n",*n2);
}
