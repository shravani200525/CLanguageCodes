#include<stdio.h>

void fundemo1(int n1,int n2,int n3);//declaration

void fundemo2(int n1,int n2);

void main()
{
	int n1=100;
	int n2=200;
	int n3=300;
	fundemo1(n1,n2,n3);//call
	fundemo2(n1,n2); //call
}

void fundemo1(int n1,int n2,int n3)
{
	printf("%d\n",n1+n2);
	printf("%d\n",n2+n3);
}

void fundemo2(int n1,int n2)
{
	printf("%d\n",n1+n2);
}
