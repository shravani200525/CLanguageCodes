#include<stdio.h>

void funDemo(int n1,int n2)
{
	printf("add=%d\n",n1+n2);
}

void main()
{
	printf("main strat\n");
	funDemo(100,100);
	printf("main end\n");
}
