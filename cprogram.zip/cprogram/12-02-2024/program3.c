#include<stdio.h>

void fundemo(int *a);
void main()
{
	int n1=10;
	printf("befor n1=%d\n",n1);
	fundemo(&n1);
	printf("after n1=%d\n",n1);
}

void fundemo(int *a)
{
	printf("%d\n",*a);
	*a=50;
	printf("%d\n",*a);
}
