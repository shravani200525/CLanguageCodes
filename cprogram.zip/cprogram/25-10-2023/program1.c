#include<stdio.h>

void main()
{
	int noofperson;
	char row;
	float ticketprice;
	printf("enter no of person\n");
	scanf("%d",&noofperson);

	printf("enter row\n");
	scanf(" %c",&row);

	printf("enter ticket price\n");
	scanf("%f",&ticketprice);

	printf("personNo=%d\n",noofperson);
	printf("row= %c\n",row);
	printf("ticket price = %f\n",ticketprice);
}
