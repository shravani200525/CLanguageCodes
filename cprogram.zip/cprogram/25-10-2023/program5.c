#include<stdio.h>

void main()
{
	int i,no=10;
	for(i=1;i<=no;i++)
	{
		printf("%d\n",i);
	}
}
