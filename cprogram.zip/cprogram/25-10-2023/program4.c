#include<stdio.h>
void main()
{
	int i;
	for(i=50; i>=1;i--)
	{
		printf("*\n");
	}
}
