#include<stdio.h>

void main()
{
	int a;

	for(a=1;a<5;a++)
	{
		printf("*\n");
	}

}
