#include<stdio.h>

void main()
{
	char pname[20];
	printf("enter name:\n");
	gets(pname);
	puts(pname);
}
