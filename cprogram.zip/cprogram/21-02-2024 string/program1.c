#include<stdio.h>

void main()
{
	char Aname[]={'k','a','r','t','i','k'};
	char *str1="ms Dhoni";
	char *str2="virat kohli";
	char *str3="hardik Pandya";
	char *str4="ms Dhoni";

	printf("%p\n",str1);
	printf("%p\n",str2);
	printf("%p\n",str3);
	printf("%p\n",str4);
}
