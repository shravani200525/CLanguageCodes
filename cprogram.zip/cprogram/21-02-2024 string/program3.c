#include<stdio.h>

void main()
{
	char Pname[20];
	printf("enter name:\n");
	scanf("%[^g]",Pname);
	puts(Pname);
}
