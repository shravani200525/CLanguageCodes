#include<stdio.h>
//void mazestrlen()
void main()
{
	char arr[]={'s','h','r','a','v','a','n','i'};
	char *str1="jidnyasa";

	int strlength1=mazestrlen(arr);
	printf("%d\n",strlength1);

	int strlength2=mazestrlen(str1);
	printf("%d\n",strlength2);
}

int mazestrlen(char *str)
{
	int count=0;
	while(*str !='\0'){
		count++;
		str++;
	}
	return(count);
}


