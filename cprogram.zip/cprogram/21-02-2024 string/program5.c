#include<stdio.h>

void fun1(char *);
void fun2(char *);

void main()
{
	char arr[]={'r','a','j'};
	char *str1="rohit";
	fun1(arr);
	fun2(str1);

}

void fun1(char *arr)
{
	puts(arr);
}
void fun2(char arr[])
{
	puts(arr);
}
