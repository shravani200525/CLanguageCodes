#include<stdio.h>

void main()
{
	char *str;
	printf("Enter your name:\n");
	scanf("%s",str);
	puts(str);
}
