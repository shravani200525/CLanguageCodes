#include<stdio.h>
void main()
{
	int age = 10;
	char wing = 'a';
	float price = 50.50;
	int __Rollno=105;
	int empid8=5;
	int 9empid =6;
	char w#R = 'p';
	char -WR = 'r';
	float WR = 'k';
}
