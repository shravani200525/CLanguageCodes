#include<stdio.h>
void main()
{
	int num1=50;
	int num2=20;
	int ans;

	//arethmetic operator
	
	puts("[1] Addition operator");
	ans= num1 + num2;
	printf("%d + %d = %d\n",num1,num2,ans);

	puts("[2] Subtraction operator");
	ans = num1- num2;
	printf("%d - %d = %d\n",num1,num2,ans);

	puts("[3] Multiplication operator");
	ans = num1* num2;
	printf("%d * %d = %d\n",num1,num2,ans);

	puts("[4] division operator (quotient)");
	ans= num1/ num2;
	printf("%d / %d = %d\n",num1,num2,ans);

	puts("[5] division operator (remainder)");
	ans = num1 % num2;
	printf("%d mod %d = %d\n",num1,num2,ans);
}
