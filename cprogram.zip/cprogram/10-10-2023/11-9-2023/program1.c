#include<stdio.h>
char c='a';
unsigned char uc=50;

short si=-12;
unsigned short usi=12;

int i=-25;
unsigned int ui=25;

long li=-89;
unsigned long uli=100;

long long lli=-56;
unsigned long long ulli=54;

float f1=3.14;
double d1=6.2564;

void main()
{
	printf("signed char %c\n",c);
	printf("unsigned char %hhu\n",uc);

	printf("signed short %hd\n",si);
	printf("unsigned short %hu\n",usi);

	printf("int %d\n",i);
	printf("unsigned int %u\n",ui);

	printf("long int%ld\n",li);
	printf("unsigned long %lu\n",uli);

	printf("long long int %lld\n",lli);
	printf("unsinged long long %llu\n",ulli);

	printf("float %f\n",f1);
	printf("double %lf\n",d1);
}
