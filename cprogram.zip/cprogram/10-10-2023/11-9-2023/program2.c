#include<stdio.h>
void main()
{
	char c='a';
	unsigned char uc=50;

	short si=-89;
	unsigned short usi=89;

	int i=-90;
	unsigned int ui=90;

	long li=-38;
	unsigned long uli= 38;

	long long lli=-20;
	unsigned long long ulli=20;

	float f1=3.456987;
	double f2=63.45874;

	printf("char %c\n",c);
	printf("unsigned char: %hhu\n",uc);

	printf("short %hd\n",si);
	printf("unsigned short: %hu\n",usi);

	printf("int:%d\n",i);
	printf("unsigned int %u\n",ui);

	printf("long %ld\n",li);
	printf("unsigned long: %lu\n",uli);

	printf("long long: %lld\n",lli);
	printf("unsigned long long: %llu\n",ulli);


	printf("float: %f\n",f1);
	printf("double: %lf\n",f2);
}
