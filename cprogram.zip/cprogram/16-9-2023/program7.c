#include<stdio.h>
void main()
{
	int a =7; int ans;
	ans = ++a + ++a + ++a;
	printf("ans=%d\n",ans);
	printf("a=%d\n",a);
}
