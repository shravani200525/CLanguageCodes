#include<stdio.h>

void main()
{
	int a=10; int ans;
	ans = a++ + a++;
	printf("ans = %d\n",ans);
	printf("a= %d\n",a);
}
