#include<stdio.h>
void fun();
int a=10;
void main()
{
	printf("start\n");
	int b=20;
	fun();
	printf("end\n");
}

void fun()
{
	int c=30;
	printf("in fun\n");
}
