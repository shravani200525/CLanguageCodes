#include<stdio.h>
int year=2023;
void getName();
void main()
{
	printf("start\n");
	int age=50;
	getName();
	printf("end\n");
}

void getName()
{
	int age=25;
	printf("inside getName fun\n");
}
