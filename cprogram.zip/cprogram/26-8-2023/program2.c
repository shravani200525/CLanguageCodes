#include<stdio.h>
void fun ();
int x=50;
void main()
{
	printf("hello\n");
	int y=60;
	fun();
	printf("to pune\n");

}
void fun()
{
	int z=70;
	printf("welcome\n");
}
