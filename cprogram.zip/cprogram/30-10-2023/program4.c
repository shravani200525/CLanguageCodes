#include<stdio.h>
void main()
{
	char ch='A';
	int i,j;
	for(i=1;i<=3;i++)
	{
		for(j=1;j<=3;j++)
		{
			printf(" %c",ch);
			ch= ch+1;
		}
		printf("\n");
	}
}
