#include<stdio.h>
void main()
{
	int num=1,i,j;
	for(i=1;i<=3;i++)
	{
		for(j=1;j<=3;j++)
		{
			printf("%d",num);
			num++;
		
		}
		printf("\n");
	}
}
