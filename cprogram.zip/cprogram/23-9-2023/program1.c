#include<stdio.h>
void main()
{
	int a = 10,b=20,result;
	result = a+b;
	printf("result:%d\n",result);
	printf("a:%d\n",a);
	printf("b:%d\n",b);
}
