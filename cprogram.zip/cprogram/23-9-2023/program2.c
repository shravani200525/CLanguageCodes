#include<stdio.h>

int add(int a,int b)
{
	int result;
	result = a+b;
}
void main()
{
	int a = add(10,20);
	int b = add(20,50);
	printf("b:%d\n",b);
	printf("a:%d\n",a);
}
