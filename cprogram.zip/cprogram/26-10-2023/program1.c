#include<stdio.h>
void main()
{
	int i;
	for(i=20;i<=40;i=i+5)
	{
		printf("%d\n",i);
	}
}
