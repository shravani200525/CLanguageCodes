#include<stdio.h>

void main()
{
	char carr[]={'R','a','j','\0'};
	printf("%s",carr);//Raj
			  
	printf("\n");	
	for(int i=0;i<3;i++)
	{
		printf("%c",carr[i]);
	
	}
	printf("\n");
	for(int i=0;i<5;i++)
	{
		printf("%c",carr[i]);
	}
	printf("\n");

	char *str="Raj";

	printf("%s",str);//Raj
			 
	printf("\n");
	for(int i=0;i<3;i++)
	{
		printf("%c",str[i]);//Raj
	}
	printf("\n");

	for(int i=0;i<5;i++)
	{
		printf("%c",str[i]);
	}
	
	printf("\n");
}
