#include<stdio.h>

void main()
{
	const int n1;
	printf("enter n1\n");
	scanf("%d",&n1);
	printf("%d\n",n1);
}
