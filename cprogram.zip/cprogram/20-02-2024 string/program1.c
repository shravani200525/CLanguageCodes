#include<stdio.h>

void main()
{
	char carr[]={'R','A','J'};//array string
	char *str="Raj";//pointer string

	printf("%s",carr);//RAJ
	printf("\n");
	printf("%s",str);//Raj
	printf("\n");

	printf("%ld\n",sizeof(carr));//3
	printf("%ld\n",sizeof(str));//8

	printf("%c\n",carr[2]);//A
	carr[2]='k';

	printf("%c\n",carr[2]);//k//A

	printf("%c\n",*str);//R
	*str='M';

	printf("%c\n",*str);//segmentation fault
	

}
