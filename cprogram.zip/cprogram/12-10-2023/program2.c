#include<stdio.h>
void main()
{
	int number;
	printf("enter the number\n");
	scanf("%d",&number);
	printf("number is= %d\n",number);
}
