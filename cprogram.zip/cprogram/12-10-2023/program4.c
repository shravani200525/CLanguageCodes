#include<stdio.h>
void main()
{
	long long int phno;
	printf("enter phno \n");
	scanf("%lld",&phno);
	printf("phno is  = %lld\n",phno);

}
