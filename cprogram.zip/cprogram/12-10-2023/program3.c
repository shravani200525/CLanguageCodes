#include<stdio.h>

void main()
{
	long int Adharno;
	printf("enter adhar no\n");
	scanf("%ld",&Adharno);
	printf("Adhar no is = %ld\n",Adharno);
}
