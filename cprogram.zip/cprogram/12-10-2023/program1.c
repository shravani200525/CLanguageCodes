#include<stdio.h>

void main()
{
	short int age;
	printf("enter the age\n");
	scanf("%hd",&age);
	printf("age is=%hd\n",age);
}
