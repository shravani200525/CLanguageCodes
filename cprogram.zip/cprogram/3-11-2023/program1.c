#include<stdio.h>
void main()
{
	int a=10;
	int b=20;
	if(a==10)
	{
		printf("inside if\n");
	}
	printf("outside if\n");
	else
	{
		printf("inside else\n");
	}
}
