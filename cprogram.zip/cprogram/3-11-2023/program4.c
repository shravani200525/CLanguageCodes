#include<stdio.h>
void main()
{
	int floor;
	printf("enter floor no\n");
	scanf("%d",&floor);
	switch(floor)
	{
		case 1:
			{
				char subfloor;
				printf("enter s for shopping \n f for food\n");
				scanf(" %c",&subfloor);
				switch(subfloor)
				{
					case 's':
						printf("you are in shopping floor\n");
						break;
					case 'f':
						printf("you are in food section\n");
						break;
				}
				break;
			}
		case 2:
			{
				char subfloor;
				printf("enter P for play station \n M for movie\n");
				scanf(" %c",&subfloor);
				switch(subfloor)
				{
					case 'P':
						printf("you are in playstation section\n");
						break;
					case 'M':
						printf("you are in movie section\n");
						break;
					default:
						printf("wrong floor\n");
						break;
				}
				break;
			}
		case 3:
			{
				char subfloor;
				printf("enter C for cricket \n B for batminten\n");
				scanf(" %c",&subfloor);
				switch(subfloor)
				{
					case 'C':
						printf("you are in cricket section\n");
						break;
					case 'B':
						printf("you are in batminten section\n");
						break;
					default:
						printf("wrong floor\n");
						break;
				}
				break;
			}
	default:
		printf("you are in outside the mall\n");
		break;
	}
}
