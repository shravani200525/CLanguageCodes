#include<stdio.h>
void main()
{
	int day;
	if(day==1)
	{
		printf("mon\n");
	}
	else if(day==2)
	{
		printf("tue\n");
	}
	else if(day==3)
	{
		printf("wed\n");
	}
	else if(day==4)
	{
		printf("thurs\n");
	}
	else if(day==5)
	{
		printf("fri\n");
	}
	else if(day==6)
	{
		printf("sat\n");
	}
	else if(day==7)
	{
		printf("sun\n");
	}
	else
	{
		printf("no days\n");
	}
}
