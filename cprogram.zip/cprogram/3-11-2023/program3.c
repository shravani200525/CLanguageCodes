#include<stdio.h>
void main()

{
	int day;
	printf("enter a day\n");
	switch(day)
	{
		case 1:
			printf("mon\n");
			break;
		case 2:
			printf("tue\n");
			break;
		case 3:
			printf("wed\n");
			break;
		case 4:
			printf("thus\n");
			break;
		case 5:
			printf("fri\n");
			break;
		case 6:
			printf("sat\n");
			break;
		case 7:
			printf("sun\n");
			break;
		default:
			printf("wrong\n");
			break;

	}
}
