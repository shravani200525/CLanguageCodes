#include<stdio.h>
void main()
{
	char veg;
	printf("enter veg food\n");
	scanf(" %c",&veg);
	switch(veg)
	{
		case 'P':
			{
				char paneer;
				printf("enter T for paneer tikka\n C for chili paneer\n");
				scanf(" %c",&paneer);
				switch(paneer)
				{
					case 'T':
						printf("you order paneer tikka\n");
						break;
					case 'C':
						printf("you order chili paneer\n");
						break;
					default:
						printf("wrong\n");
						break;
				}
				break;
			}
		case 'A':
			{
				char Aloo;
				printf("enter D for dum aloo\n P for potato spring\n");
				scanf(" %c",&Aloo);
				switch(Aloo)
				{
					case 'D':
						printf("you order dum aloo\n");
						break;
					case 'P':
						printf("you order potato spring\n");
						break;
				}
				break;
			}
		case 'R':
			{
				char Roti;
				printf("enter N for naan\n R for rumali roti\n");
				scanf(" %c",&Roti);
				switch(Roti)
				{
					case 'N':
						printf("you order naan\n");
						break;
					case 'R':
						printf("you order rumali roti\n");
						break;
				}
				break;
			}
		default:
			printf("enter correct input\n");

		
	}
}
